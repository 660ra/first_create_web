function test(){
    window.alert(' external(외부) 방식 실행됨!!');
}